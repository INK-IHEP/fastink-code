# XRootD Interface for FastAPI

## Usage

Importing `src.routers.fs.fs_manager` to use fs module.