jupyter_ngix = "http://aiweb01.ihep.ac.cn:8443/jupyter"
krb5_server = "https://aiweb02.ihep.ac.cn:8802/"
xrd_server = "root://aiweb02.ihep.ac.cn:1094/"

#krb5_enabled = True
krb5_enabled = False
loglevel = 'ERROR'
